Metarhia is a [🌍 community](community/index.md),
a [⚙️ technology stack](technology/index.md) and
[🛠️ R&D center](rnd.md) for cloud computing, high-intensive network
applications and distributed systems.

We are not a company or a business, we are professionals. Our approach is to
provide services based of open-source technologies and build a culture of
knowledge-driven development. We work as individuals but can do large things as
a team.

- What we propose: see [🤝 collaboration](partnership/index.md) opportunities.
- What we do: see [✨ services](services/index.md).
- [📫 Contact](contacts.md) our coordinator for more info.

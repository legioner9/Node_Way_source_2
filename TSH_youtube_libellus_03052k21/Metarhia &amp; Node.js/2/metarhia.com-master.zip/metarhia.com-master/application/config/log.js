({
  keepDays: 100,
  writeInterval: 3000,
  writeBuffer: 64 * 1024,
  toFile: ['error', 'warn', 'info', 'debug', 'log'],
  toStdout: ['error', 'warn', 'info', 'debug', 'log'],
});

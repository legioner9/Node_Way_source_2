## Object-oriented programming

[![Have Objects Failed? Или что не так с ООП?](https://img.youtube.com/vi/4yO5OS0vPSw/0.jpg)](https://www.youtube.com/watch?v=4yO5OS0vPSw)

[![ООП: построение абстракций, инкапсуляция и сокрытие](https://img.youtube.com/vi/sQwF6-bYeDM/0.jpg)](https://youtu.be/sQwF6-bYeDM)

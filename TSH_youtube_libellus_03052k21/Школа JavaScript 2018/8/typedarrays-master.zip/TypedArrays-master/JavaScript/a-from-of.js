'use strict';

console.log(Int8Array.from([1, 2, 3]));
console.log(Int8Array.of(1, 2, 3));
console.log(Int8Array.of(...[1, 2, 3]));

# Binary Buffers

[![Работа с файлами, буферами и файловыми потоками](https://img.youtube.com/vi/eQGBS15vUac/0.jpg)](https://www.youtube.com/watch?v=eQGBS15vUac)

# Asynchronity with Promise
[![Асинхронность на промисах, Promise, all, then, catch, race](https://img.youtube.com/vi/RMl4r6s1Y8M/0.jpg)](https://www.youtube.com/watch?v=RMl4r6s1Y8M)

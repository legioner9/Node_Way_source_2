## Functions, lambda-functions, function contexts, closures

[![Функции, лямбды, контексты, замыкания](https://img.youtube.com/vi/pn5myCmpV2U/0.jpg)](https://www.youtube.com/watch?v=pn5myCmpV2U)

# Качество, тестирование и надежность ПО

- [Измерение производительности кода и оптимизация в JavaScript и Node.js](https://youtu.be/sanq2X7Re8o)
  - Примеры кода: https://github.com/HowProgrammingWorks/Benchmark
- [Тестирование: юнит-тесты с примерами на JavaScript](https://youtu.be/CszugIag2TA)
  - Примеры кода: https://github.com/HowProgrammingWorks/Testing
  - Примеры кода: https://github.com/HowProgrammingWorks/Unittesting
- [Тестирование: системное и интеграционное тестирование на JavaScript](https://youtu.be/OuKu_6H_6gE)
  - Примеры кода: https://github.com/HowProgrammingWorks/Unittesting

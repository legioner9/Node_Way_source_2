## Reflect API

[![Интроспекция и рефлексия в JavaScript](https://img.youtube.com/vi/yvW1PjUVeM0/0.jpg)](https://www.youtube.com/watch?v=yvW1PjUVeM0)

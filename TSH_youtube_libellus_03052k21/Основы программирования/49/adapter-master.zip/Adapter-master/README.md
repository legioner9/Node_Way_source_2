## Pattern Adapter Implementations

[![Адаптер (Adapter) - паттерн достижения совместимости](https://img.youtube.com/vi/cA65McLQrR8/0.jpg)](https://www.youtube.com/watch?v=cA65McLQrR8)

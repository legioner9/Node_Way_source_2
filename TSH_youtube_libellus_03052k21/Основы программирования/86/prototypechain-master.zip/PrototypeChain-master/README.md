## Прототипное программирование и прототипное наследование

[![Прототипное программирование и прототипное наследование](https://img.youtube.com/vi/SzaXTW2qcJE/0.jpg)](https://www.youtube.com/watch?v=SzaXTW2qcJE)

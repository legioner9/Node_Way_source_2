# Different implementation of iterations as a code abstraction

[![Массивы, объекты, классы, прототипы](https://img.youtube.com/vi/VBMGnAPfmsY/0.jpg)](https://www.youtube.com/watch?v=VBMGnAPfmsY)
[![Итерирование, циклы и итераторы](https://img.youtube.com/vi/lq3b5_UGJas/0.jpg)](https://www.youtube.com/watch?v=lq3b5_UGJas)

<h2>C# Example Results:</h2>

![image](https://cloud.githubusercontent.com/assets/12159879/26380369/e4cc60b2-4026-11e7-9223-50d94f2d8624.png)

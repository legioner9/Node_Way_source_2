# RegExp
Regular Expression is a Syntax to Define String Pattern

[![Регулярные выражения и парсинг](https://img.youtube.com/vi/-ef2E0ozxao/0.jpg)](https://www.youtube.com/watch?v=-ef2E0ozxao)

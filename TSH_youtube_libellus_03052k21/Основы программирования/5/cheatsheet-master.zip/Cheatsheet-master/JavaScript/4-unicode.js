'use strict';

const 人 = (α, β, γ) => (α + β + γ);
const ツ = (α, γ) => 人(α, 10, γ);
console.log(ツ(2, 3));

const расстрелять = '🔫';
console.log(расстрелять);

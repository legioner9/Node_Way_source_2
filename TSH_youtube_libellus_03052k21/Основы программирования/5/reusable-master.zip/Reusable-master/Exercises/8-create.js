'use strict';

const createUser = null;

module.exports = { createUser };

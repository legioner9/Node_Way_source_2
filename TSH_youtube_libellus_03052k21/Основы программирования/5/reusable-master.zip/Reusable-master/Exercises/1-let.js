'use strict';

let name = undefined;

module.exports = { name };

## Введение: основные абстракции и повторное использование

- Упражнения: [Exercises.ru.md](Exercises.ru.md)
- Примеры: [JavaScript](JavaScript)

[![Базовый синтаксис JavaScript](https://img.youtube.com/vi/xJn3k1f4BiM/0.jpg)](https://www.youtube.com/watch?v=xJn3k1f4BiM)

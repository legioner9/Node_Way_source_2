'use strict';

const compose = (...fns) => x => null;

module.exports = { compose };

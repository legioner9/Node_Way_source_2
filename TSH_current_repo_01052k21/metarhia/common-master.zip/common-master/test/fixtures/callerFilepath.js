'use strict';

const common = require('../../');

module.exports = depth => common.callerFilepath(depth);

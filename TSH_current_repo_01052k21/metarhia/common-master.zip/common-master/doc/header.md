# Metarhia Common Library

![CI Status Badge](https://github.com/metarhia/common/workflows/Tests/badge.svg?branch=master)
[![Codacy Badge](https://api.codacy.com/project/badge/Grade/57f219ad89e64c848685a93f5f2f14c2)](https://www.codacy.com/app/metarhia/common)
[![NPM Version](https://badge.fury.io/js/%40metarhia%2Fcommon.svg)](https://badge.fury.io/js/%40metarhia%2Fcommon)
[![NPM Downloads/Month](https://img.shields.io/npm/dm/@metarhia/common.svg)](https://www.npmjs.com/package/@metarhia/common)
[![NPM Downloads](https://img.shields.io/npm/dt/@metarhia/common.svg)](https://www.npmjs.com/package/@metarhia/common)

Namespace: `api.common` in [Impress Application Server](https://github.com/metarhia/Impress)

## Installation

```bash
$ npm install @metarhia/common
```

## API

//
//  JSTP.h
//  JSTP
//
//  Created by Andrew Visotskyy on 7/19/16.
//  Copyright © 2016 Andrew Visotskyy. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for JSTP.
FOUNDATION_EXPORT double JSTPVersionNumber;

//! Project version string for JSTP.
FOUNDATION_EXPORT const unsigned char JSTPVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <JSTP/PublicHeader.h>



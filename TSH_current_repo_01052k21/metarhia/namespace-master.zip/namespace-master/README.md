# High stable namespace registry

[![TravisCI](https://travis-ci.org/metarhia/namespace.svg?branch=master)](https://travis-ci.org/metarhia/namespace)
[![bitHound](https://www.bithound.io/github/metarhia/namespace/badges/score.svg)](https://www.bithound.io/github/metarhia/namespace)

## Installation

```bash
$ npm install namespace
```

## Objects to store in namespace

  - algorithms
  - data structures
  - modules
  - components
  - tools

## Contributors

  - Timur Shemsedinov (marcusaurelius)
  - See github for full [contributors list](https://github.com/metarhia/metasync/graphs/contributors)

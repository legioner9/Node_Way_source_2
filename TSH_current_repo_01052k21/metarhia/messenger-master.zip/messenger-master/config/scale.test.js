{
  cloud: 'PrivateCloud',
  server: 'S1',
  instance: 'standalone',

  key: 'edec4a498a604f2da754d173cd58b361', // Cloud access key
  cookie: 'node',

  firewall: {
    enabled: false
  },

  health: '5s',
  nagle: false,
  gc: 0,
  watch: '1s'
}

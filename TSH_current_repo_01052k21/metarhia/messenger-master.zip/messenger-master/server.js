require('impress');

impress.server.start();

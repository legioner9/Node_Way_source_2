# Metarhia Messenger

## Installation

```sh
$ npm install

# If you want a developer build with code-watching,
# fast background rebuild and automatic page reload:

$ npm run dev

# If you want a production build:

$ npm run build
```

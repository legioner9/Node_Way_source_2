(callback) => {
  api.auth.signOut(connection, callback);
}

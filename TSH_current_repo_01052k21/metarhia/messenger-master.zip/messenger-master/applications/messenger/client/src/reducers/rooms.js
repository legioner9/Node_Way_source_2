const initialState = {
};

export default function rooms(state = initialState, action) {
  return state;
}

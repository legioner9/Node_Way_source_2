import { combineReducers } from 'redux';

import rooms from './rooms';

export default {
  rooms
};

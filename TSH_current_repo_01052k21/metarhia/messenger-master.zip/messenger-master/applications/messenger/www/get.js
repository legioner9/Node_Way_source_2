(client, callback) => {
  callback();
}

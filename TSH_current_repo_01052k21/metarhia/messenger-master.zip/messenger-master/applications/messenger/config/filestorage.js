application.extCompressed = [
  'gif','jpg','jpe','jpeg','png','svgz',
  'docx','xlsx','pptx','dotx','odm','odt','ott','odp','otp','djvu','djv',
  'zip','rar','z7','gz','jar','arj',
  'iso','nrg','img','apk',
  'mp2','mp3','mp4','avi','flv','fla','swf','3gp','mkv','mpeg','mpg','mpe','mov','asf','wmv','vob'
];

application.extNotCompressed = [
  'txt','pdf','doc','dot','xls','ppt','rtf','hlp','inf','eml','uu','uue',
  'css','htm','html','xhtml','tpl','vsd','chm','ps',
  'bmp','ico','eps','svg','psd','ai','tif','tiff','wmf','emf','ani','cur','wav','wave','mid',
  'bak','sql','csv','xml','rss','atom','url','torrent',
  'bas','js','php','pl','pm','py','c','cpp','cs','d','e','h','inc','java','m','pas','dpr','prg','asp','aspx','ini','asm','res','bat','cmd',
  'exe','dll','com','obj','ocx','sys','msi'
];

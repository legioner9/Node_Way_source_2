'use strict';

console.log('Tests stub');

'use strict';

require('impress'); // eslint-disable-line import/no-unresolved
impress.server.start();

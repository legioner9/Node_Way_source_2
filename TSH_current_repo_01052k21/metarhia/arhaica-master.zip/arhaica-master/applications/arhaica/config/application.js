{
  slowTime: '1s'
}

{

  index: true,
  cacheSize: '50mb',
  cacheMaxFileSize: '10mb',
  gzip: true,
  preprocess: [
    // 'js',
    // 'sass'
  ]

}

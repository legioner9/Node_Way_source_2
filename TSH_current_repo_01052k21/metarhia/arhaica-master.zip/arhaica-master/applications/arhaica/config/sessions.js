{
  anonymous: true,
  cookie: 'SID',
  characters: 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',
  secret: 'secret',
  length: 64,
  persist: true,
  perIpLimit: '20',
  perUserLimit: '5',
  //confirmTime: '1m',
  //expireTime: '2m',
}

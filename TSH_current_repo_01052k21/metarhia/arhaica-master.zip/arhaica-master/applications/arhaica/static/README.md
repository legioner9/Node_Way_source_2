Folder for static files: client-side js, images, styles, etc.

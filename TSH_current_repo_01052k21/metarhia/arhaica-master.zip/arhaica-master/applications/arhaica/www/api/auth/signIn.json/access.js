{
  guests: true,
  logged: false,
  http:   true,
  https:  true,
  groups: []
}

{
  guests: true,
  logged: true,
  http:   true,
  https:  true,
  intro:  true,
  groups: []
}

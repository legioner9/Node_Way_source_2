{
  guests: false,
  logged: true,
  http:   true,
  https:  true,
  intro:  false,
  groups: []
}

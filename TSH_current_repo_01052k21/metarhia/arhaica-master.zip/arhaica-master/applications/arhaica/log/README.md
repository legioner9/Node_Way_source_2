Folder for fog files

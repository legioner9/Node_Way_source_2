(a, b, c, callback) => {
  callback(null, a + b + c);
}

IMPRESS_MODE=prod node --stack-trace-limit=1000 server.js

# --max_old_space_size=2048
# --no-warnings
# --nouse-idle-notification
# --expose-gc

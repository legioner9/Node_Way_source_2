# @metarhia/iterator - efficient and composable iteration

[![CI Status Badge](https://github.com/metarhia/iterator/workflows/Tests/badge.svg?branch=master)](https://github.com/metarhia/iterator/actions?query=workflow%3A%22Tests%22+branch%3Amaster)

## Installation

```bash
$ npm install @metarhia/iterator
```

## API

## Contributors

See github for full [contributors list](https://github.com/metarhia/iterator/graphs/contributors)

# Metarhia Data Serialization Format

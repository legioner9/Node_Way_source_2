'use strict';

module.exports = [
  {
    name: 'true',
    value: true,
    serialized: 'true',
  },
  {
    name: 'false',
    value: false,
    serialized: 'false',
  },
];

'use strict';

module.exports = [
  {
    name: 'null',
    value: null,
    serialized: 'null',
  },
];

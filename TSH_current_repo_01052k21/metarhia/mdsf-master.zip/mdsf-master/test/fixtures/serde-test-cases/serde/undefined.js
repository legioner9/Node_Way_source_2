'use strict';

module.exports = [
  {
    name: 'undefined',
    value: undefined,
    serialized: 'undefined',
  },
];

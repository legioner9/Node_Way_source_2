'use strict';

module.exports = [].concat(
  require('./boolean'),
  require('./number'),
  require('./string'),
  require('./null'),
  require('./undefined'),
  require('./array'),
  require('./object')
);

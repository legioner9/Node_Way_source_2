'use strict';

module.exports = [].concat(
  require('./number'),
  require('./string'),
  require('./array'),
  require('./object')
);

'use strict';

module.exports = [
  {
    name: 'sparse array',
    value: [1, undefined, 3],
    serialized: '[1,,3]',
  },
];

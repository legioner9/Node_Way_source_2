'use strict';

module.exports = [
  {
    name: 'Boolean object',
    value: new Boolean(true),
    serialized: 'true',
  },
];

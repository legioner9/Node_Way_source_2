'use strict';

module.exports = [].concat(
  require('./boolean'),
  require('./number'),
  require('./string'),
  require('./array'),
  require('./object')
);

'use strict';

module.exports = [].concat(require('./object'));

'use strict';

module.exports = [].concat(require('./number'));

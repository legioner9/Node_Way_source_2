'use strict';

module.exports = {
  serialization: require('./serialization'),
  deserialization: require('./deserialization'),
};

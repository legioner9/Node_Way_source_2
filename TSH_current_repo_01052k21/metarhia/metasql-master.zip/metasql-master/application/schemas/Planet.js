({
  Planet: 'global dictionary',

  name: { type: 'string', unique: true },
});

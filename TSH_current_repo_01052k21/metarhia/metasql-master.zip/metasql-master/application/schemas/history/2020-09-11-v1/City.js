({
  country: 'Country',
  name: { type: 'string', unique: true },
});

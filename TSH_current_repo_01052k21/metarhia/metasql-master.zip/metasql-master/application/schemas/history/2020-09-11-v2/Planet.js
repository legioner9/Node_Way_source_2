({
  name: 'string',
});

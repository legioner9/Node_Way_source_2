# Advanced Topics

This section outlines topics that are not required and barely interesting for
most users of the library, but essential for hacking the library itself or
reimplementing the protocol for other platforms and languages.

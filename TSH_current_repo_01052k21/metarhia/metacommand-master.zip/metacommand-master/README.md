# Metarhia command-line interface utilities

[![CI Status](https://github.com/metarhia/metacommand/workflows/Testing%20CI/badge.svg)](https://github.com/metarhia/metacommand/actions?query=workflow%3A%22Testing+CI%22+branch%3Amaster)
[![NPM Version](https://badge.fury.io/js/metacommand.svg)](https://badge.fury.io/js/metacommand)
[![NPM Downloads/Month](https://img.shields.io/npm/dm/metacommand.svg)](https://www.npmjs.com/package/metacommand)
[![NPM Downloads](https://img.shields.io/npm/dt/metacommand.svg)](https://www.npmjs.com/package/metacommand)

# Readable and Writable Streams with buffering

[![TravisCI](https://travis-ci.org/metarhia/metastreams.svg?branch=master)](https://travis-ci.org/metarhia/metastreams)
[![Codacy Badge](https://api.codacy.com/project/badge/Grade/d51a3d27efd743638a020128ddad1397)](https://www.codacy.com/app/metarhia/metastreams)
[![NPM Version](https://badge.fury.io/js/metastreams.svg)](https://badge.fury.io/js/metastreams)
[![NPM Downloads/Month](https://img.shields.io/npm/dm/metastreams.svg)](https://www.npmjs.com/package/metastreams)
[![NPM Downloads](https://img.shields.io/npm/dt/metastreams.svg)](https://www.npmjs.com/package/metastreams)

## Contributors

See GitHub for a full [list of contributors](https://github.com/metarhia/metadoc/graphs/contributors)

## License

Licesed under MIT license. Copyright (c) 2018 Metarhia contributors

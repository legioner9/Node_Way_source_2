# Metarhia Community Manifesto

- [Манифест технологического стека Метархия](/RU/Technology.md)
- [Манифест инженера](/RU/Engineer.md)
- [Обращение к партнерам](/RU/Partner.md)
- [Обращение к начинающему инженеру](/RU/Beginner.md)

# Metarhia Technology Stack Manifesto

0. **Simplicity**
1. **JavaScript**
2. **Other languages**
3. **Technology Stack**
4. **Optimization**
5. **Homogeneous nodes**
6. **Isolation**
7. **Stateful**
8. **Open source**
9. **Interactivity**
10. **Global identification**
11. **Multi-paradigm approach**
12. **Layered architecture**
13. **People make difference**

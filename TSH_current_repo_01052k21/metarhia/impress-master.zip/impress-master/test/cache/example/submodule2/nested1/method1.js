() => {
  console.debug('Call method: example.submodule2.nested1.method1');
};

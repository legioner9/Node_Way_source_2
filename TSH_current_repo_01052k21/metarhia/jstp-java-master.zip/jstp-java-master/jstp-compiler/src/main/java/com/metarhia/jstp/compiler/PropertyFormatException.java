package com.metarhia.jstp.compiler;

/**
 * Created by lundibundi on 8/13/16.
 */
public class PropertyFormatException extends Exception {

  public PropertyFormatException(String message) {
    super(message);
  }
}

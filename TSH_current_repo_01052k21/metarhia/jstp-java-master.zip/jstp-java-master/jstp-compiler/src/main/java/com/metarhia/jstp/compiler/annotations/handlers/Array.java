package com.metarhia.jstp.compiler.annotations.handlers;

/**
 * Created by lundibundi on 8/7/16.
 */
public @interface Array {

  int[] value();
}

package com.metarhia.jstp.compiler.annotations.handlers;

/**
 * Created by lundibundi on 8/9/16.
 */
public @interface Mixed {

  String[] value();
}

package com.metarhia.jstp.compiler;

/**
 * Created by lundibundi on 8/8/16.
 */
public class ExceptionHandlerInvokeException extends Exception {

  public ExceptionHandlerInvokeException(String s) {
    super(s);
  }
}

package com.metarhia.jstp.compiler.annotations.handlers;

/**
 * Created by lundibundi on 5/23/17.
 */
public @interface NoDefaultGet {

}

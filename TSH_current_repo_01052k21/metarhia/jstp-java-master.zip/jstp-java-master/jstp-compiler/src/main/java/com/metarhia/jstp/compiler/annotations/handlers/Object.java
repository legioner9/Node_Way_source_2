package com.metarhia.jstp.compiler.annotations.handlers;

public @interface Object {

  String[] value();
}

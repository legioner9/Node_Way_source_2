package com.metarhia.jstp.compiler.annotations.proxy;

/**
 * Created by lundibundi on 5/25/17.
 */
public @interface Call {

  String[] value() default "";
}

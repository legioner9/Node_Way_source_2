package com.metarhia.jstp.compiler.annotations.handlers;

import java.lang.annotation.ElementType;
import java.lang.annotation.Target;

/**
 * Created by lundibundi on 2/12/17.
 */
@Target({ElementType.METHOD, ElementType.PARAMETER})
public @interface NotNull {

}

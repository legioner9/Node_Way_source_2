package com.metarhia.jstp.core.JSTypes;

/**
 * Created by lundibundi on 8/24/16.
 */
public class JSTypesUtilTest {

}

package com.metarhia.jstp.core.JSInterfaces;

/**
 * Created by lundibundi on 5/20/17.
 */
public interface JSSerializable {

  StringBuilder stringify(StringBuilder builder);
}

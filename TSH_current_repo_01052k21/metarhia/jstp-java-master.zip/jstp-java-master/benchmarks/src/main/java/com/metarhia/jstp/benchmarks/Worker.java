package com.metarhia.jstp.benchmarks;

public interface Worker {

  void work();
}

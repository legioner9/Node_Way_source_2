'use strict';

['client', 'server'].map((test) => require('./' + test));

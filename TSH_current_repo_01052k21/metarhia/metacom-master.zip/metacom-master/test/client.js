'use strict';

console.log('No client tests implemented');

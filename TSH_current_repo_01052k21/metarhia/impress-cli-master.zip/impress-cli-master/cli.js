#!/usr/bin/env node

'use strict';

console.log('This module is temporary frozen');

[![impress logo](http://habrastorage.org/files/d67/1b3/be5/d671b3be591d47a9bd10fe857e9d5319.png)](https://github.com/metarhia/impress-cli)

This module is a part of [Impress](https://github.com/metarhia/impress)
Application Server for [node.js](http://nodejs.org). This module is temporarily
frozen but will be rewritten after Impress 2.0 release.

## Contributors

- Timur Shemsedinov (marcusaurelius) &lt;timur.shemsedinov@gmail.com&gt;
- See github for full [contributors list](https://github.com/metarhia/impress-cli/graphs/contributors)

Copyright (c) 2015-2019 Impress Application Server contributors

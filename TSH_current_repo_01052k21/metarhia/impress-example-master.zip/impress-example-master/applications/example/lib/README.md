Place for application libraries

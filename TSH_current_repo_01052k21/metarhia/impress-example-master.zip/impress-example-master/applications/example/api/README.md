Folder for application APIs

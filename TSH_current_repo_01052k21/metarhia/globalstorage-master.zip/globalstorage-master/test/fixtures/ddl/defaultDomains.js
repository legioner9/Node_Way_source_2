'use strict';

module.exports = () => ({
  name: 'generateDDL with default domains',
  schemas: [],
  // SQL for default Metaschema domains will be added by test runner
  expectedSql: '',
});

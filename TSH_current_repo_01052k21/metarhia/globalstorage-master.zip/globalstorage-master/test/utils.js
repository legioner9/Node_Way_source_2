'use strict';

const pgOptions = {
  user: 'postgres',
  password: '',
  host: 'localhost',
  database: 'test_globalstorage_database',
  port: 5432,
};

module.exports = {
  pgOptions,
};

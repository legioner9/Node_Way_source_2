'use strict';

module.exports = {
  rules: {
    strict: ['error', 'global'],
  },
};

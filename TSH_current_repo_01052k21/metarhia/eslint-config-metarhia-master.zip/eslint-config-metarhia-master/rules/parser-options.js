'use strict';

module.exports = {
  parserOptions: {
    ecmaVersion: 2020,
  },
};

[
  ['Marcus Aurelius','212-04-26','Rome'],
  ['Victor Glushkov','1923-08-24','Rostov on Don'],
  ['Ibn Arabi','1165-11-16','Murcia'],
  ['Mao Zedong','1893-12-26','Shaoshan'],
  ['Rene Descartes','1596-03-31','La Haye en Touraine']
]
[
  { name: 'Marcus Aurelius', birth: { day: '212-04-26', city: 'Rome' } },
  { name: 'Victor Glushkov', birth: { day: '1923-08-24', city: 'Rostov on Don' } },
  { name: 'Ibn Arabi', birth: { day: '1165-11-16', city: 'Murcia' } },
  { name: 'Mao Zedong', birth: { day: '1893-12-26', city: 'Shaoshan' } },
  { name: 'Rene Descartes', birth: { day: '1596-03-31', city: 'La Haye en Touraine' } }
]
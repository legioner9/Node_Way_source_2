[
  { name: 'Marcus Aurelius', birth: new Date('212-04-26'), city: 'Rome' },
  { name: 'Victor Glushkov', birth: new Date('1923-08-24'), city: 'Rostov on Don' },
  { name: 'Ibn Arabi', birth: new Date('1165-11-16'), city: 'Murcia' },
  { name: 'Mao Zedong', birth: new Date('1893-12-26'), city: 'Shaoshan' },
  { name: 'Rene Descartes', birth: new Date('1596-03-31'), city: 'La Haye en Touraine' }
]
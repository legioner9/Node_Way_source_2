(person) => (
  person.name !== '' &&
  person.age > 18 &&
  person.city === 'Rome'
)
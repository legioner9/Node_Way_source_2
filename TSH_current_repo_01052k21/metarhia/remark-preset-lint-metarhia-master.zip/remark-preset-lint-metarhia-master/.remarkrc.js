'use strict';

module.exports = {
  plugins: [require('.')],
};

async (data) => {
  const result = data.unknownKey();
  return result;
};

(function mul(a, b) {
  const result = a * b;
  return result;
});

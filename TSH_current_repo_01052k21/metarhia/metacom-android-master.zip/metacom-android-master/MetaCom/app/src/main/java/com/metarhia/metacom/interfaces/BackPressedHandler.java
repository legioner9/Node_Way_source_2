package com.metarhia.metacom.interfaces;

/**
 * Created by masha on 7/31/17.
 */

public interface BackPressedHandler {
    public void handleBackPress();
}

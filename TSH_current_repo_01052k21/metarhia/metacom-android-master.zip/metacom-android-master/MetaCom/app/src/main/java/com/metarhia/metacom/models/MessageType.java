package com.metarhia.metacom.models;

/**
 * Type of message
 *
 * @author lidaamber
 */

public enum MessageType {

    FILE,
    TEXT,
    INFO
}

package com.metarhia.metacom.interfaces;

/**
 * @author MariaKokshaikina
 */

public interface DownloadFileByCodeListener {

    void downloadByCode(String code);
}

import React from 'react';
import ReactDOM from 'react-dom';
import MainContainer from './packages/app/containers/Main/MainContainer';

ReactDOM.render(<MainContainer />, document.getElementById('root'));

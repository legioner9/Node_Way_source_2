## Integration testing

[![Тестирование: системное и интеграционное тестирование на JavaScript](https://img.youtube.com/vi/OuKu_6H_6gE/0.jpg)](https://www.youtube.com/watch?v=OuKu_6H_6gE)

# ACID
Atomicity, Consistency, Isolation, Durability

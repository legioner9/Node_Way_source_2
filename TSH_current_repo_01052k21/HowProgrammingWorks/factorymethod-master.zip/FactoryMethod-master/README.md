# Factory method

Define an abstract class (or an interface) for object instantiation, but let
subclasses (or interface implementation) decide which class to instantiate.

## Deferred (and comparison to Future and Promise)

[![Deferred: Асинхронность на диферах с состоянием](https://img.youtube.com/vi/a2fVA1o-ovM/0.jpg)](https://www.youtube.com/watch?v=a2fVA1o-ovM)

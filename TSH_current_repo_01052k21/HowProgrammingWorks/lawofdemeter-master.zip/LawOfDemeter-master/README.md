# LawOfDemeter
Law of Demeter (LoD) principle of least knowledge in component coupling

# OpenClosed
The Open Closed Principle

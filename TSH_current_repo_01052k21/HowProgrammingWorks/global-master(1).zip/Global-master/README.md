# Global
Global context pollution problem

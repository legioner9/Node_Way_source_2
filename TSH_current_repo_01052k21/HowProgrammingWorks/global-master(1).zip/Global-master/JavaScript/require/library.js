'use strict';

const f1 = x => x;

const f2 = () => 'result';

module.exports = { f1, f2 };

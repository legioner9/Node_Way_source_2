# DbC
Programming by contract, Design by contract (DbC), Contract-based Programming

# Single instance

[![Шаблон Singleton (синглтон)](https://img.youtube.com/vi/qdJ5yikZnfE/0.jpg)](https://www.youtube.com/watch?v=qdJ5yikZnfE)

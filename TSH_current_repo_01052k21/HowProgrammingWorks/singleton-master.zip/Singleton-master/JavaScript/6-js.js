'use strict';

// But what a bullshit?
// It's a JavaScript, not an OOP
// We can just use {}

const singleton = {};

// Usage

console.assert(singleton === singleton);
console.log('instances are equal');

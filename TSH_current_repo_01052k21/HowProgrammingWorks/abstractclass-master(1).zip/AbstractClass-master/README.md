# AbstractClass
Abstract class can't be instantiated directly

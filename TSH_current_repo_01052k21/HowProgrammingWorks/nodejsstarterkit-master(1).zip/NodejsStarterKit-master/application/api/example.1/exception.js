async () => {
  throw new Error('Hello', 12345);
};

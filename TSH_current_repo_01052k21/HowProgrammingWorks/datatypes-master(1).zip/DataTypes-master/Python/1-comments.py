# single comment

 
"""    
    Multiline comments do not actualy exist in Python
    Sometimes you can meet creating of multiline comments by using tripple quotes,
    but that is not a comments in general.
    Tripple quotes in python treats as regular string and
    if it is not assigned to any variable it will be immediately garbage collected
    as soon as that code executes. So it doesn't affect execution. 
"""
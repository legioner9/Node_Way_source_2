'use strict';

const inc = null;

module.exports = { inc };

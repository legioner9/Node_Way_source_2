# Abstract Factory Pattern

Define an abstract class (or an interface) for creating families of related or
dependent objects without specifying their concrete classes.

# Multi-paradigm Approach to the Software Engineering

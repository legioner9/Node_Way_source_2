'use strict';

const inc = (n) => n + 1;

module.exports = { inc };

## Future as Asynchronous Abstraction

[![Future: Асинхронность на фьючерах без состояния](https://img.youtube.com/vi/22ONv3AGXdk/0.jpg)](https://www.youtube.com/watch?v=22ONv3AGXdk)

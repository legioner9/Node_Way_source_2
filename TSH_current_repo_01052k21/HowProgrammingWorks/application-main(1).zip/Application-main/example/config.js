export default {
  key: 'value',
};

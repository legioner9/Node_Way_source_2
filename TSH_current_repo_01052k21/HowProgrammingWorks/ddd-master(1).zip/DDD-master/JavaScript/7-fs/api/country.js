'use strict';

const db = require('../db.js');

module.exports = db('country');

# SQLConstraints
SQL constraints: indexes, checks, nullable, primary and foreign keys

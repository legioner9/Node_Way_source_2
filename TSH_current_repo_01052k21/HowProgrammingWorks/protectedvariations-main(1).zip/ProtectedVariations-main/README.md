# ProtectedVariations
GRASP: Protected Variations principle

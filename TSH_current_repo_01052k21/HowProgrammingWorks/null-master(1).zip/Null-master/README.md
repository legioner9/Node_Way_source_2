# Null
NPE, Null object, Optional, Maybe

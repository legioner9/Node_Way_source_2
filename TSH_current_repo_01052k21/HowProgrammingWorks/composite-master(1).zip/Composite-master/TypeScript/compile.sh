tsc --target ESNext 1-interface.ts
tsc --target ESNext 2-abstract.ts

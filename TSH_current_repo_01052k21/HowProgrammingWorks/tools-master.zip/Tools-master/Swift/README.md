# Swift Development Tools
| [English](README.md) | [Русский](README.ru.md) |

(document is under development)

Required software:
  1. Compilers:
  2. Linters:
  3. VCS - Version Control System - [GitHub](https://github.com/), [Git](https://git-scm.com/), [GUI](https://desktop.github.com/)

Optional tools:
  1. IDE - Integrated development environment:
  2. CI - Continuous Integration:

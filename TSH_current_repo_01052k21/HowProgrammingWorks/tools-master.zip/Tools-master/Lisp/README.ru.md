# Инструменты разработчика Lisp
| [English](README.md) | [Русский](README.ru.md) |

(документ в процессе написания)

Обязательные компоненты:
  1. Компиляторы:
  2. Линтеры:
  3. VCS - система контроля версий - [GitHub](https://github.com/), [Git](https://git-scm.com/), [GUI](https://desktop.github.com/)

Опциональные компоненты:
  1. IDE - редактор или среда разработки: [Brackets](http://brackets.io/), [Atom](https://atom.io/)

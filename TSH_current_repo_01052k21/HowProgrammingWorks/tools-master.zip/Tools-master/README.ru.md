# Инструменты разработчика
| [English](README.md) | [Русский](README.ru.md) |

Инструменты для разработки и конфигурация окружения для следующих языков:
  1. [JavaScript](JavaScript/README.ru.md)
  2. [Haskell](Haskell/README.ru.md)
  3. [Python](Python/README.ru.md)
  4. [C++](C++/README.ru.md)
  5. [Go](Go/README.ru.md)
  6. [Swift](Swift/README.ru.md)
  7. [Java](Java/README.ru.md)
  8. [Lisp](Lisp/README.ru.md)
  9. [C&#35;](CSharp/README.ru.md)

# Development Tools
| [English](README.md) | [Русский](README.ru.md) |

Here are development tools and environment configuration for following languages:
  1. [JavaScript](JavaScript/README.md)
  2. [Haskell](Haskell/README.md)
  3. [Python](Python/README.md)
  4. [C++](C++/README.md)
  5. [Go](Go/README.md)
  6. [Swift](Swift/README.md)
  7. [Java](Java/README.md)
  8. [Lisp](Lisp/README.md)
  9. [C&#35;](CSharp/README.md)

# GRASP
General Responsibility Assignment Software Patterns

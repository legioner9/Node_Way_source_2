# Certification in Software Engineering

## Requirements

- [Node.js with asynchronity, architecture, security and databases](Requirements/NodeJS.ru.md)

## Public certificates

| Level        | 2019 | 2020 | 2021 |
| ------------ | ---- | ---- | ---- |
| Basics       |      |      |      |
| Advanced     | [3](Public/2-Advanced/2019/README.md) | [2](Public/2-Advanced/2020/README.md) | |
| Specialist   |      |      |      |
| Expert       |      |      |      |
| Lecturer     |      |      |      |

# Advanced Knowledge in Software Engineer

* Жуков Михаил Александрович https://github.com/DarthPigrum
* Ковалишин О. Ю. https://github.com/ALEGATOR1209
* Лепейко Евгений Владимирович https://github.com/jn-lp

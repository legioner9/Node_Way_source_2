# Advanced Knowledge in Software Engineer

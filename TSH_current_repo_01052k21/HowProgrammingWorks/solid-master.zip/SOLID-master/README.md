# SOLID
Single responsibility, Open-closed, Liskov substitution, Interface segregation и Dependency inversion

node --nouse-idle-notification --expose-gc application.js

# Factory
[![Фабрики и пулы объектов](https://img.youtube.com/vi/Ax_mSvadFp8/0.jpg)](https://www.youtube.com/watch?v=Ax_mSvadFp8)

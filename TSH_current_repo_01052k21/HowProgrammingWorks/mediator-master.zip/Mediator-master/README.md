# Mediator
Define an interaction between instances as a separate instance

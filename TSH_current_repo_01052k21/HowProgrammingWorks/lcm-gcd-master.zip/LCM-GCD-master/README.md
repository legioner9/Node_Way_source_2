# lcm-gcd
Least Common Multiple and Greatest common divisor

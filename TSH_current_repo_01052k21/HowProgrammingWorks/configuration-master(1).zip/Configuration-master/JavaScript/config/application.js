({
  name: 'Application name',
  author: 'Timur Shemsedinov',
});

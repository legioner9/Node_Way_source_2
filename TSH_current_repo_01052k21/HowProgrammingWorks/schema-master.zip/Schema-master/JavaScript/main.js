'use strict';

(async () => {
  console.log('Module stub');
})();

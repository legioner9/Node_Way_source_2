[![Мономорфный и полиморфный код, инлайн-кэш, скрытые классы в JavaScript](https://img.youtube.com/vi/9JUY3prnCQ4/0.jpg)](https://www.youtube.com/watch?v=9JUY3prnCQ4)

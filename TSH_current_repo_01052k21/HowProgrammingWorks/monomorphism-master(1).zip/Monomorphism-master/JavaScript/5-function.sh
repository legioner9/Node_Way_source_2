clear
node --trace-deopt --trace-opt 5-function.js

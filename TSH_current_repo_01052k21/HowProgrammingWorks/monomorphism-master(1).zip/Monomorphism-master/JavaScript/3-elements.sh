clear
node --trace-elements-transitions 3-elements.js

# InterfaceSegregation
The Interface Segregation Principle

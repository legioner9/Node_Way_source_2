# Indirection
GRASP: Indirection pronciple

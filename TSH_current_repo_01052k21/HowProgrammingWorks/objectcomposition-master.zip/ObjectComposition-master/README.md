# ObjectComposition
Object Composition or Aggregation

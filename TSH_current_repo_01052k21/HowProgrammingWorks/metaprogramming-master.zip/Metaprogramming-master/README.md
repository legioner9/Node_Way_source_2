## Metaprogramming with JavaScript examples

[![Метапрограммирование с примерами на JavaScript](https://img.youtube.com/vi/Ed9onRv4G5Y/0.jpg)](https://www.youtube.com/watch?v=Ed9onRv4G5Y)

# StateMachine
Finite-State Machine or Finite-State Automaton

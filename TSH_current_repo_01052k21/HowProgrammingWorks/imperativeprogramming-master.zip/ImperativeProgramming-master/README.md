# ImperativeProgramming
Imperative, non-structured, structured and procedural programming

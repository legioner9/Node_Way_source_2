'use strict';

console.log('Write logs with console.log');
console.dir({ example: [0, 1, 2, 3] });
console.error('Error message');

# Structured Query Language

[![Введение в SQL: SELECT](https://img.youtube.com/vi/Z679c8S0d7I/0.jpg)](https://youtu.be/Z679c8S0d7I)

[![Введение в SQL: CREATE, ALTER, DROP, ключи, индексы](https://img.youtube.com/vi/QF0v29ZneYE/0.jpg)](https://youtu.be/QF0v29ZneYE)

function convert(n){
	var parts = n.split("/");
	var gramm =  ( ( (parts.length == 1) ? parseInt(parts[0]) : parseInt(parts[0]) / parseInt(parts[1]) ) * 28.3495231 ).toFixed(2);
	return  isNaN(gramm) ? "--" : gramm;
}



document.addEventListener('DOMContentLoaded', function() {	
	chrome.tabs.executeScript( null, {"code": "window.getSelection().toString()"}, function(selection) {
		  var selectedText = selection[0];
		  var result = "";
		  if (selectedText != ""){
			selectedText = selectedText.replace(/\s+/g, '');  
			var numbers = selectedText.split("-");			
			result = convert(numbers[0]);
						
			if (numbers.length == 2){
				result += " - " + convert(numbers[1]);	
			}
						
			result += " г";
		  }
		  else result = "----"
		  document.getElementById("output").innerHTML = result;
		});
});


import { ParamsBuilder } from './params-builder';

// Params builder for PostgreSQL database
export class PostgresParamsBuilder extends ParamsBuilder<Array<any>> {}

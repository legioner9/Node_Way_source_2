# Metarhia certification

- JavaScript applied software engineering
- JavaScript frontend software engineering
- JavaScript asynchronous and parallel programming
- Enterprise information system software engineering
- Node.js applied software engineering
- Node.js system software engineering

Please [📫 contact](contacts.md) our coordinator for more info.

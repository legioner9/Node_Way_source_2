# Collaboration and partnership

Collaboration offers for:
[🗃️ project](partnership/project.md),
[🏢 enterprise](partnership/enterprise.md),
[💻 outsourcing](partnership/outsourcing.md),
[🔍 HR agency](partnership/hr.md),
[🎓 education](partnership/education.md) centers,
individual [👨 beginner](partnership/beginner.md) specialist, and
experienced [👷 professional](partnership/professional.md).

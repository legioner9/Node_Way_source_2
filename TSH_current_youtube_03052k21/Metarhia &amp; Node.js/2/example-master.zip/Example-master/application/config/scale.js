({
  cloud: 'PrivateCloud',
  server: '1',
  instance: 'standalone',
  token: 'ap14-me0b/6jtl9i:8d7$k8901d556*g',
  gc: 60 * 60 * 1000,
});

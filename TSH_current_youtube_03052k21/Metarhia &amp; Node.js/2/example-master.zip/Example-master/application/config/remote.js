({
  url: 'ws://localhost:8001',
  interfaces: ['example'],
});

({
  keepDays: 10,
  writeInterval: 1000,
  writeBuffer: 64 * 1024,
  toFile: ['error', 'warn', 'info', 'debug', 'log'],
  toStdout: ['error', 'warn', 'info', 'debug', 'log'],
});

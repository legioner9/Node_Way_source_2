## IoC - Inversion of Control (old examples)

See new examples in following repos:
- [DI / Dependency Injection](https://github.com/HowProgrammingWorks/DependencyInjection)
- Component [sandboxing](https://github.com/HowProgrammingWorks/Sandboxes)

[![Инверсия управления и внедрение зависимостей](https://img.youtube.com/vi/Fz86Fdjz-LM/0.jpg)](https://www.youtube.com/watch?v=Fz86Fdjz-LM)

#!/bin/sh
node --allow-natives-syntax --nouse-idle-notification --expose-gc 3-instantiation

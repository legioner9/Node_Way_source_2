'use strict';

module.exports = api => {

  api.moduleName.first = value => value;

  api.moduleName.second = value => value;

};

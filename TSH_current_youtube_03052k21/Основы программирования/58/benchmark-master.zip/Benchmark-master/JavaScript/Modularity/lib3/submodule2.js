'use strict';

module.exports = api => {

  api.moduleName.third = value => value;

  api.moduleName.fourth = value => value;

};

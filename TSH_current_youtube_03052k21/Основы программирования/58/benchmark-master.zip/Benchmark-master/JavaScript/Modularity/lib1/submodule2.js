'use strict';

function third(value) {
  return value;
}

function fourth(value) {
  return value;
}

module.exports = { third, fourth };

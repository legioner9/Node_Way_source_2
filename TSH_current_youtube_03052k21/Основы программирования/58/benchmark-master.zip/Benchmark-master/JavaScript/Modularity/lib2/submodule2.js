'use strict';

const moduleName = {};
module.exports = moduleName;

moduleName.third = value => value;

moduleName.fourth = value => value;

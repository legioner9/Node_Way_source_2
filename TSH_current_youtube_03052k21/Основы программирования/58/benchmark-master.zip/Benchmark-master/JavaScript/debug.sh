#!/bin/sh

node --inspect $1

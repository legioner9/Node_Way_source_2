#!/bin/sh
node --allow-natives-syntax --nouse-idle-notification e-copy-dataset

## Asynchronous Function Composition

[![Асинхронная композиция функций](https://img.youtube.com/vi/3ZCrMlMpOrM/0.jpg)](https://www.youtube.com/watch?v=3ZCrMlMpOrM)

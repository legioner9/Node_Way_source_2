# Data Driven Programming
[![Реактивное программирование](https://img.youtube.com/vi/7MH8-qQc-48/0.jpg)](https://www.youtube.com/watch?v=7MH8-qQc-48)

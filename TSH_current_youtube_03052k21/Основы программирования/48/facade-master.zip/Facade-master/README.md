## Pattern Facade Implementations

[![Необработанные ошибки в промисах на Node.js](https://img.youtube.com/vi/oJtBO7CystE/0.jpg)](https://www.youtube.com/watch?v=oJtBO7CystE)

# FunctionalProgramming
[![Функциональное программирование](https://img.youtube.com/vi/0JxSs_GcvbQ/0.jpg)](https://www.youtube.com/watch?v=0JxSs_GcvbQ)

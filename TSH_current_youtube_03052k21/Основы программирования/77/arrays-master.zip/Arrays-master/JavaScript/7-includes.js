'use strict';

{
  const array = [10, 20, 30, 40];
  console.log(array.includes('a'));
}
{
  const array = [10, 20, 30, 40];
  console.log(array.includes(40));
}

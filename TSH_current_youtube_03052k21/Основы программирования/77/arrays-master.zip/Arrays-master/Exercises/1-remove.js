'use strict';

const removeElement = (array, item) => {
  // Remove item from array modifying original array
};

module.exports = { removeElement };

## Antipatterns as a Worst Practices

| [![Антипаттерны общие для всех парадигм](https://img.youtube.com/vi/NMUsUiFokr4/0.jpg)](https://youtu.be/NMUsUiFokr4) | [![Антипаттерны процедурного программирования](https://img.youtube.com/vi/cTv7V22mkwE/0.jpg)](https://youtu.be/cTv7V22mkwE) |
|---|---|
| [![Антипаттерны ООП (часть 1)](https://img.youtube.com/vi/9d5TG1VsLeU/0.jpg)](https://youtu.be/9d5TG1VsLeU) | |

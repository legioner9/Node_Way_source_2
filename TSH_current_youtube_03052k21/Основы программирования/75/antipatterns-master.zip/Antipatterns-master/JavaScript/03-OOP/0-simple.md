## Simple antipatterns

- Duplicate code
- Hardcode
- Magic numbers
- Criptic code
- Accidental complexity
- Long method
- Long inheritance
- Long identifier
- Large class
- Dead and unreachable code
- Too many parameters
- Pass-through parameters
- Accumulate and fire
- Use switch/case (or multiple if statements)

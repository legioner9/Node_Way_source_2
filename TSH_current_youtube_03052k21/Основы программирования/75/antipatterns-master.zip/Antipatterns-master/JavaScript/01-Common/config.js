'use strict';

module.exports = {
  name: {
    lenght: 17
  },
  fileName: '2-hard-code.js',
};

tsc --target ESNext 1-association.ts
tsc --target ESNext 2-aggregation.ts
tsc --target ESNext 3-composition.ts

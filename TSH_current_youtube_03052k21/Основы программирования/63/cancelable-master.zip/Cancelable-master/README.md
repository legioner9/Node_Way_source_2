## Cancellable Asynchronous Abstractions

[![Отмена асинхронных операций: cancelable callback and Promise](https://img.youtube.com/vi/T8fXlnqI4Ws/0.jpg)](https://www.youtube.com/watch?v=T8fXlnqI4Ws)

const sum = <T>(a: T, b: T): T => a + b;
console.log(sum(1, 2));

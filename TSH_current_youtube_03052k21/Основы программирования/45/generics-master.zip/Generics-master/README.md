## Generic Programming

[![Дженерики и обобщенное программирование](https://img.youtube.com/vi/r6W2z3DQhoI/0.jpg)](https://www.youtube.com/watch?v=r6W2z3DQhoI)

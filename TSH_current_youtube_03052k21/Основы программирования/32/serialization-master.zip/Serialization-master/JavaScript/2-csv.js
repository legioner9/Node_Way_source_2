'use strict';

const arr = [
  [ 7, 10, 12,  5],
  [ 3,  1,  2,  3],
  [10,  9, 11, 77],
  [ 5, 18,  6, 26]
];

const s = arr.join('\n');

console.log(s);

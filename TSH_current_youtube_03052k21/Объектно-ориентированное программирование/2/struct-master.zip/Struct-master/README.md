# Struct (structure or record)

[![Структуры (struct) или записи (record)](https://img.youtube.com/vi/Wb7o_kK4aH4/0.jpg)](https://youtu.be/Wb7o_kK4aH4)

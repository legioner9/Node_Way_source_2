## Actor model (concurrent computation model)

[![Модель акторов для параллельных вычислений](https://img.youtube.com/vi/xp5MVKEqxY4/0.jpg)](https://www.youtube.com/watch?v=xp5MVKEqxY4)

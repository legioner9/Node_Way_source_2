# Non blocking loops
[![Неблокирующее асинхронное итерирование](https://img.youtube.com/vi/wYA2cIRYLoA/0.jpg)](https://www.youtube.com/watch?v=wYA2cIRYLoA)

## Reactive Extensions (Rx)

[![Асинхронность на RxJS и потоки событий](https://img.youtube.com/vi/0kcpMAl-wfE/0.jpg)](https://www.youtube.com/watch?v=0kcpMAl-wfE)

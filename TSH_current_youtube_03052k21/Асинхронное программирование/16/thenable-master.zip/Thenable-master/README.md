## Thenable contract

[![Thenable и легковесный await в JavaScript](https://img.youtube.com/vi/DXp__1VNIvI/0.jpg)](https://www.youtube.com/watch?v=DXp__1VNIvI)

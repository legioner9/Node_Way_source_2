# Timers: setImmediate, setTimeout, setInterval, nextTick
[![Таймеры, таймауты, EventEmitter](https://img.youtube.com/vi/LK2jveAnRNg/0.jpg)](https://www.youtube.com/watch?v=LK2jveAnRNg)

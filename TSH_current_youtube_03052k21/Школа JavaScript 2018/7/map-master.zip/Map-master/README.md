# Map as Associative Array

[![Коллекции, множества, хештаблицы](https://img.youtube.com/vi/hN0wsq5LNOc/0.jpg)](https://www.youtube.com/watch?v=hN0wsq5LNOc)

Tasks:
- Implement `Map` polyfill with 2 arrays: for keys and for values
- Implement Iterable interface in polyfill, see: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Iteration_protocols

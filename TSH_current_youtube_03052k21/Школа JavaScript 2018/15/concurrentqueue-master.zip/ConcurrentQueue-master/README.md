## Asynchronous Concurrent Queue with Priority and Factor

[![Конкурентная асинхронная очередь на JavaScript](https://img.youtube.com/vi/Lg46AH8wFvg/0.jpg)](https://www.youtube.com/watch?v=Lg46AH8wFvg)

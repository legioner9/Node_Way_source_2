# GRASP: Low coupling and High cohesion

[![Зацепление и связность / coupling and cohesion](https://img.youtube.com/vi/IGXdPOZ3Fyk/0.jpg)](https://www.youtube.com/watch?v=IGXdPOZ3Fyk)

# Callbacks, Listeners and Events

[![Функции высшего порядка, колбеки, события](https://img.youtube.com/vi/1vqATwbGHnc/0.jpg)](https://youtu.be/1vqATwbGHnc)

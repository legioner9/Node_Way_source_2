## Binary Semaphore, Counting Semaphore

[![Семафоры и мьютексы в JavaScript и Node.js](https://img.youtube.com/vi/JNLrITevhRI/0.jpg)](https://www.youtube.com/watch?v=JNLrITevhRI)

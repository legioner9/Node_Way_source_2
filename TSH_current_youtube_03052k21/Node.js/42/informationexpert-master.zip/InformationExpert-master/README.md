# GRASP: Information Expert

[![Принцип информационный эксперт / Information Expert](https://img.youtube.com/vi/cCHL329_As0/0.jpg)](https://www.youtube.com/watch?v=cCHL329_As0)

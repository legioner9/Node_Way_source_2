# Abstractions

Programming with any paradigm is an abstractions so here we will collect
code examples for different paradigms to illustrate good and bad practices
in building abstractions.

[![Слои, связанность и связность кода](https://img.youtube.com/vi/A3RpwNlVeyY/0.jpg)](https://www.youtube.com/watch?v=A3RpwNlVeyY)

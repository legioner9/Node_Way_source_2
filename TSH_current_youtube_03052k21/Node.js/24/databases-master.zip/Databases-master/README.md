# Databases and SQL

[![Базы данных в 2020 (введение, история, состояние)](https://img.youtube.com/vi/8RjT2VYBWNQ/0.jpg)](https://youtu.be/8RjT2VYBWNQ)

[![PostgreSQL: установка, настройка, консоль](https://img.youtube.com/vi/Fm6yLb8qCh4/0.jpg)](https://youtu.be/Fm6yLb8qCh4)

[![Работа с базами данных в Node.js на примере PostgreSQL](https://img.youtube.com/vi/2tDvHQCBt3w/0.jpg)](https://youtu.be/2tDvHQCBt3w)

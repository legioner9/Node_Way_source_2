```

[cat fun]
    <>cnt_un
    
    ON branch master
    $ Changes to be committed:{{modified:   v1}}
    $ Changes not staged for commit:{{modified:   v1}}
    $ Untracked files:{{fun}}
    $$ not checked in to index{{@@ -1 +1 @@
                                    -cnt_2
                                    +cnt_3}}
    $$ checked in to index but not committed{{v1:@@ -1 +1 @@
                                                    -cnt_1
                                                    +cnt_2}}
    $$ 4016163: master -> v1=cnt_1{{v1:@@ -1 +1 @@
                        -cnt_0
                        +cnt_1}}
    $$ 74779f5: master, remotes/bare/master -> v1=cnt_0{{v1:@@ -0,0 +1 @@
                                                        +cnt_0}}

* 4016163 - (2 minutes ago) v1=cnt_1 - Legioner9 (HEAD -> master)
* 74779f5 - (13 hours ago) v1=cnt_0 - Legioner9 (bare/master)



------------------------------------------------------------------------------
[go](../proj.2.0.0/SandBoxes/SpawningNewBranch/create.1.0.0_to_2.0.0/set.1.0.0._to.2.0.0.v.1/v1)

[gh -b brn] 
<>Switched to a new branch 'brn'

    ON branch brn
    $ Changes to be committed:{{modified:   v1}}
    $ Changes not staged for commit:{{modified:   v1}}
    $ Untracked files:{{fun}}
    $$ not checked in to index{{@@ -1 +1 @@
                                    -cnt_2
                                    +cnt_3}}
    $$ checked in to index but not committed{{v1:@@ -1 +1 @@
                                                    -cnt_1
                                                    +cnt_2}}
    $$ 4016163: brn, master -> v1=cnt_1{{v1:@@ -1 +1 @@
                        -cnt_0
                        +cnt_1}}
    $$ 74779f5: master, remotes/bare/master -> v1=cnt_0{{v1:@@ -0,0 +1 @@
                                                        +cnt_0}}

* 4016163 - (3 days ago) v1=cnt_1 - Legioner9 (HEAD -> brn, master)
* 74779f5 - (13 hours ago) v1=cnt_0 - Legioner9 (bare/master)

------------------------------------------------------------------------------

        remaine[gh master]
        <>
        ............
        * 4016163 - (3 days ago) v1=cnt_1 - Legioner9 (HEAD -> master, brn)


------------------------------------------------------------------------------
[go](../proj.2.0.0/SandBoxes/SpawningNewBranch/create.1.0.0_to_2.0.0/set.1.0.0._to.2.0.0.v.2/v1)

[gc v1 -m v1=cnt_2]
    <>[brn 6f97660] v1=cnt_2
    1 file changed, 1 insertion(+), 1 deletion(-)
    [cat v1]
    <>cnt_1

    ON branch brn
    $ Untracked files:{{fun}}    

    $$ 6f97660: brn: -> v1=cnt_2{{v1:@@ -1 +1 @@
                                             -cnt_1
                                            +cnt_3}}

    $$ 4016163: brn, master -> v1=cnt_1{{v1:@@ -1 +1 @@
                        -cnt_0
                        +cnt_1}}
    $$ 74779f5: master, remotes/bare/master -> v1=cnt_0{{v1:@@ -0,0 +1 @@
                                                        +cnt_0}}

* 6f97660 - (12 seconds ago) v1=cnt_2 - Legioner9 (HEAD -> brn)
* 4016163 - (3 days ago) v1=cnt_1 - Legioner9 (master)
* 74779f5 - (4 days ago) v1=cnt_0 - Legioner9 (bare/master)


------------------------------------------------------------------------------
[go](../proj.2.0.0/SandBoxes/SpawningNewBranch/create.1.0.0_to_2.0.0/set.1.0.0._to.2.0.0.v.3/v1)

[gh master]
    <>Switched to branch 'master'
    [cat v1]
    <>cnt_1

    ON branch master
    $ Untracked files:{{fun}} 

    $$ 6f97660: brn: -> v1=cnt_2{{v1:@@ -1 +1 @@
                                             -cnt_1
                                            +cnt_3}}

    $$ 4016163: brn, master -> v1=cnt_1{{v1:@@ -1 +1 @@
                        -cnt_0
                        +cnt_1}}
    $$ 74779f5: master, remotes/bare/master -> v1=cnt_0{{v1:@@ -0,0 +1 @@
                                                        +cnt_0}}

* 6f97660 - (22 minutes ago) v1=cnt_2 - Legioner9 (brn)
* 4016163 - (9 days ago) v1=cnt_1 - Legioner9 (HEAD -> master)
* 74779f5 - (10 days ago) v1=cnt_0 - Legioner9 (bare/master)


------------------------------------------------------------------------------
[go](../proj.2.0.0/SandBoxes/SpawningNewBranch/create.1.0.0_to_2.0.0/set.1.0.0._to.2.0.0.v.4/v1)

[echo cnt_4 > v1]
    <>
    [cat v1]
    <>cnt_1

    ON branch master
    $ Changes not staged for commit:{{modified:   v1}}
    $ Untracked files:{{fun}} 

    $$ 6f97660: brn: -> v1=cnt_2{{v1:@@ -1 +1 @@
                                             -cnt_1
                                            +cnt_3}}

    $$ not checked in to index{{v1:@@ -1 +1 @@
                                        -cnt_1
                                        +cnt_4}}

    $$ 4016163: brn, master -> v1=cnt_1{{v1:@@ -1 +1 @@
                        -cnt_0
                        +cnt_1}}
    $$ 74779f5: master, remotes/bare/master -> v1=cnt_0{{v1:@@ -0,0 +1 @@
                                                        +cnt_0}}

* 6f97660 - (22 minutes ago) v1=cnt_2 - Legioner9 (brn)
* 4016163 - (9 days ago) v1=cnt_1 - Legioner9 (HEAD -> master)
* 74779f5 - (10 days ago) v1=cnt_0 - Legioner9 (bare/master)

------------------------------------------------------------------------------
[go](../proj.2.0.0/SandBoxes/SpawningNewBranch/create.1.0.0_to_2.0.0/set.1.0.0._to.2.0.0.v.5/v1)

[gc v1 -m v1=cnt_4]
<>[master 594d4a4] v1=cnt_4
 1 file changed, 1 insertion(+), 1 deletion(-)

    ON branch master
    $ Untracked files:{{fun}} 

    $$ 594d4a4: master -> v1=cnt_4{{v1:@@ -1 +1 @@
                        -cnt_1
                        +cnt_4}}
    $$ 6f97660: brn: -> v1=cnt_2{{v1:@@ -1 +1 @@
                                             -cnt_1
                                            +cnt_3}}

    $$ 4016163: brn, master -> v1=cnt_1{{v1:@@ -1 +1 @@
                        -cnt_0
                        +cnt_1}}
    $$ 74779f5: master, remotes/bare/master -> v1=cnt_0{{v1:@@ -0,0 +1 @@
                                                        +cnt_0}}


* 594d4a4 - (4 minutes ago) v1=cnt_4 - Legioner9 (HEAD -> master)
| * 6f97660 - (69 minutes ago) v1=cnt_2 - Legioner9 (brn)
|/
* 4016163 - (9 days ago) v1=cnt_1 - Legioner9
* 74779f5 - (10 days ago) v1=cnt_0 - Legioner9 (bare/master)

------------------------------------------------------------------------------
[go](../proj.2.0.0/SandBoxes/SpawningNewBranch/create.1.0.0_to_2.0.0/set.1.0.0._to.2.0.0.v.6/v1)

[echo cnt_5 > v1]
[gc v1 -m v1=cnt_5]
    <>[master 057224d] v1=cnt_5
    1 file changed, 1 insertion(+), 1 deletion(-)

    ON branch master
    $ Untracked files:{{fun}} 

    $$ 057224d: master -> v1=cnt_5{{v1:@@ -1 +1 @@
                        -cnt_4
                        +cnt_5}}
    $$ 594d4a4: master -> v1=cnt_4{{v1:@@ -1 +1 @@
                        -cnt_1
                        +cnt_4}}
    $$ 6f97660: brn: -> v1=cnt_2{{v1:@@ -1 +1 @@
                                             -cnt_1
                                            +cnt_3}}

    $$ 4016163: brn, master -> v1=cnt_1{{v1:@@ -1 +1 @@
                        -cnt_0
                        +cnt_1}}
    $$ 74779f5: master, remotes/bare/master -> v1=cnt_0{{v1:@@ -0,0 +1 @@
                                                        +cnt_0}}

* 057224d - (4 minutes ago) v1=cnt_5 - Legioner9 (HEAD -> master)
* 594d4a4 - (42 minutes ago) v1=cnt_4 - Legioner9
| * 6f97660 - (2 hours ago) v1=cnt_2 - Legioner9 (brn)
|/
* 4016163 - (9 days ago) v1=cnt_1 - Legioner9
* 74779f5 - (10 days ago) v1=cnt_0 - Legioner9 (bare/master)

------------------------------------------------------------------------------
[go](../proj.2.0.0/SandBoxes/SpawningNewBranch/create.1.0.0_to_2.0.0/set.1.0.0._to.2.0.0.v.7/v1)

[gh brn]
    <>Switched to branch 'brn'
[echo cnt_6 > v1]
[gc v1 -m v1=cnt_6]
    <>[brn bd7b93d] v1=cnt_6
    1 file changed, 1 insertion(+), 1 deletion(-)

    ON branch brn
    $ Untracked files:{{fun}} 

    $$ 057224d: master -> v1=cnt_5{{v1:@@ -1 +1 @@
                        -cnt_4
                        +cnt_5}}
    $$ 594d4a4: master -> v1=cnt_4{{v1:@@ -1 +1 @@
                        -cnt_1
                        +cnt_4}}
    $$ bd7b93d: brn: -> v1=cnt_6{{v1:@@ -1 +1 @@
                                             -cnt_3
                                            +cnt_6}}
    $$ 6f97660: brn: -> v1=cnt_2{{v1:@@ -1 +1 @@
                                             -cnt_1
                                            +cnt_3}}

    $$ 4016163: brn, master -> v1=cnt_1{{v1:@@ -1 +1 @@
                        -cnt_0
                        +cnt_1}}
    $$ 74779f5: master, remotes/bare/master -> v1=cnt_0{{v1:@@ -0,0 +1 @@
                                                        +cnt_0}}

* bd7b93d - (3 minutes ago) v1=cnt_6 - Legioner9 (HEAD -> brn)
* 6f97660 - (2 hours ago) v1=cnt_2 - Legioner9
| * 057224d - (16 minutes ago) v1=cnt_5 - Legioner9 (master)
| * 594d4a4 - (54 minutes ago) v1=cnt_4 - Legioner9
|/
* 4016163 - (9 days ago) v1=cnt_1 - Legioner9
* 74779f5 - (10 days ago) v1=cnt_0 - Legioner9 (bare/master)

------------------------------------------------------------------------------

[]
    <>
    ON branch ...
    $ nothing to commit, working tree clean
    $ Changes to be committed:{{}}
    $ Changes not staged for commit:{{}}
    $ Untracked files:{{}}

    $$ not checked in to index{{file:}}
    $$ checked in to index but not committed{{file:}}

    $$ hash: Branch: -> Precedes:{{file:}}

------------------------------------------------------------------------------

[]
    <>
    ON branch ...
    $ nothing to commit, working tree clean
    $ Changes to be committed:{{}}
    $ Changes not staged for commit:{{}}
    $ Untracked files:{{}}

    $$ not checked in to index{{file:}}
    $$ checked in to index but not committed{{file:}}

    $$ hash: Branch: -> Precedes:{{file:}}

------------------------------------------------------------------------------

        remaine[]
        <>
        ............

```
    (*)            
    {shape_8}={
        {st}={}
        {fs}={
            v1:'cng_2',
        }
        {ws}={
            v1:'cng_2',
        }
        {in}={
            v1:'cng_1',
        }
        {lr}={
            bare:::2fb793a::v1:'',
        }
        {ur}={
            2fb793a::v1:'',
        }
    (*)
        {{}}
            [git mv v1 v2]
                <>...
                [gs]
                    <>Changes to be committed:
                        deleted:    v1
                        new file:   v2
                    Changes not staged for commit:
                        modified:   v2
                [gw]
                    <>*prev*
                [gg]
                    <>*prev*
    (*)            
    {shape_...}={
        {st}={}
        {fs}={
            v2:'cng_2',
        }
        {ws}={
            v2:'cng_2',
        }
        {in}={
            v2:'cng_1',
            deleted:    v1,
        }
        {lr}={
            bare:::2fb793a::v1:'',            
        }
        {ur}={*prev*}
        }

    


-------------------------------
    (*)
        {{}}
            []
                <>
                [gs]
                    <>
                [gw]
                    <>
                [gg]
                    <>
    (*)            
    {shape_...}={
        {st}={}
        {fs}={}
        {ws}={}
        {in}={}
        {lr}={}
        {ur}={}
        }
-------------------------------
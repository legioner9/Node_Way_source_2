export function Scripts() {
  return {
    getScript,
    register,
  };

  function getScript(/*scriptType, activity*/) {}
  function register(/*activity*/) {}
}

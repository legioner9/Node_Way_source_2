Changelog
=========

# 4.3.4

- Fix multiple start events not completing process. Diverging flows to different ends stalled execution

# 4.3.3

- Bump `smqp@3.2`

# 4.3.2

- For some anxious reason parallel join gateways were initialized over and over again when inbound flows were touched. This stops now. A recovered and resumed run can now continue instead of waiting for neurotic joins. Thankyou @mdwheele for this discovery.

# 4.3.1

- Stop throwing errors when failing to parse `timeDuration` or `timeDate` as it was before and still should've been before someone changed it

# 4.3.0

Timetracking

- New [environment](/docs/Environment.md) [timers]((/docs/Timers.md)) property with tracked `setTimeout` and `clearTimeout`. Used by TimerEventDefinition and by inline scripts if necessary

# 4.2.0

Flaky formatting

- Add tests for formatting workaround by publishing directly to `format-run-q`
- Support formatting failure by adding `errorRoutingKey` or just publish format message with routing key ending in `.error`

# 4.1.4

Outbound sequence flows again.

- Remove redundant outbound sequence flow logic in Inclusive- and ExclusiveGateway. Flag ExclusiveGateway that only one should be taken
- If no outbound sequence was taken when activity completes the activity will throw. As it did in the above gateways. This might break stuff, but I guess it actually should

# 4.1.3

## Bugfix
- Wrap conditional sequence flow script error in an Activity error

# 4.1.2

## Bugfix
- Return something else than undefined when calling definition run (!). The definition is returned.

# 4.1.1

## Bugfix
- Formatting message on activity end resulted in nasty bug where outbound flows were affected and run stopped prematurely. This stops now.

# 4.1.0

- Make sure resumed activity wait events are emitted with a flag indicating that they are resumed - `content.isRecovered`. Can facilitate decisions regarding save state and stop. A more proper name would've been `isResumed` but `isRecovered` was used by `SignalTask`. No need for a breaking major for this small addition

# 4.0.0

Refactor scripts again

## Breaking
- ScriptTask now requires that a script is returned by [Script handler](/docs/Scripts.md) can off course return a dummy function
- Conditional SequnceFlow respects script if returned by script handler

# 3.1.0

- All sequence flows with condition, regardless of language, can use script condition using [register function](/docs/Scripts.md#registeractivity). If condition language is stipulated then script is required.

# 3.0.0

## Breaking
- Outbound sequence flow with script condition requires `next(err, result)` to be called where result decides if it should be taken or discarded

## Addititions
- Outbound sequence flow conditions are evaluated for all activities, as well as default flow
- Process now also have `cancelActivity` function for facilitation

# 2.1.0

Transactions and compensation if canceled.

## Additions
- Add support for Transaction
- Add support for CancelEventDefinition

# 2.0.0

Diagram sequence flow order affects recover as per [engine issue 105](https://github.com/paed01/bpmn-engine/issues/105).

- Refactored outbound flow handling to an extent that flows are now taken and discarded before leaving the activity run
- As an effect of above - SequenceFlow pre flight event disappeared
- Bonus: Make EventBasedGateway behave as it should

# 1.6.1

## Bugfix:
- Resumed definition with multiple loopbacks ran towards infinity, thats now finit as expected since there is an end to the fun. Thankyou @aowakennomai for uncovering bug

# 1.6.0

- Publish `definition.resume` event when Definition is resumed

# 1.5.0

- Include input when throwing signal or message

# 1.4.0

Run a non-executable process.

## Additions
- Add support for runnning a process that is NOT marked as executable by calling `definition.run({processId})`

## Bugfix
- Multiple start events were not resumed in an orderly fashion when recovered, process was stuck, but is no more
- Include occasional sub process sequence when shaking activities

# 1.3.0

[TimerEventDefinition](/docs/TimerEventDefinition.md) `timeDate` and `timeCycle`.

## Additions
- Add support for TimerEventDefinition `timeDate`. Will behave like `timeDuration` unless the date is due - timeout
- TimerEventDefinition `timeCycle` is recognized but no timer is started. The non-action is due to uncertainty regarding cycle format. The event definition is stalled and waits for cancel
- New [`cancelActivity`](/docs/Definition.md#cancelactivitymessage) function is added to definition
- TimerEventDefinition now recognises api cancel calls. Which comes in handy if a time cycle is identified and needs to continue

# 1.2.0

- a start event with form that is waiting for input can now also be signaled from definition

# 1.1.0

## Additions
- Add shake functionality to [definition](/docs/Definition.md) to facilitate getting the run sequences of an activity or processes by calling `definition.shake([activityId])`

## Patch
- Bump to smqp@3
- Patch copyright year

# 1.0.0

Make it easier and possible to signal activities from [definition](/docs/Definition.md) by calling `definition.signal(message)`.

## Breaking
- MessageEventDefinition and SignalEventDefinition will only listens for pre-execution messages if contained in a starting event

## Bugfix
- Parallel looped ReceiveTask iterations all completed with one message, that was not intended and doesn't anymore. One message equals one completed iteration

## Minor
- Bump to smqp@2.2
- Bump dev dependencies

# 0.13.1

- Bump to smqp@2
- Bump dev dependencies

# 0.12.1

- Patch `moddle-context-serializer` to relieve project from nasty bug where message flows sourcing from empty lane threw find of undefined

# 0.12.0

- Allow override of default expression handling and parsing
- Map BusinessRuleTask to ServiceTask

# 0.11.0

- Execute extensions when initiating process

# 0.10.0

- Recover now recovers environment as well

## Bugfix
- getting state no longer throws if a placeholder activity is in activities

# 0.9.0

## Addition
- Compensation is now supported, but only by association

## Bugfix
- Fix weird code where context ignores passed SequenceFlow and MessageFlow Behaviour function when making new instances

# 0.8.1

- Expose SequenceFlow name in published events and in api

# 0.8.0

- Support StandardLoopCondition

# 0.7.0

- Support LinkEventDefinition

# 0.6.1

- Defensive resume #8

# 0.6.0

Focused on messaging.

## Breaking
- ReceiveTask expects referenced message, it can still be signaled
- IntermediateCatchEvent that lacks event definitions now expects to be signaled
- Catching MessageEventDefinition expects referenced message. or at least a matching message id

## Additions
- IntermediateThrowEvent with MessageEventDefinition now throws Message
- Start activities conforming to the same flow is discarded when the flow reaches an end activity, unless a join is put in between

# 0.5.0

- allow a waiting UserTask to trigger an execution error
- catch signal fired before event execution

# 0.4.0

## Breaking
- Catching ErrorEventDefinition now catches BpmnErrors. Support for catching by error code and anonymous errors is still supported
- Event with throwing ErrorEventDefinition now throws non-fatal BpmnErrors

## Additions
- Expose element name on Api
- Extension function `deactivate` is now actually called, called on leave and stop

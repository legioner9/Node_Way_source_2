/* global module */
module.exports = function babelRoot(api) {
  api.cache(true);

  return {
    presets: [
      [
        '@babel/env', {
          targets: {
            node: 'current',
          },
        }
      ]
    ],
  };
};

Resources
=========

All modeled with [Camunda modeler](https://camunda.org/download/modeler/).

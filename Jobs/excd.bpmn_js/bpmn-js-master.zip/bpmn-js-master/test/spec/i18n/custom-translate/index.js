import customTranslate from './custom-translate';

export default {
  translate: [ 'value', customTranslate ]
};
> Removed as of `dmn-js@1.0.0`.

We've discontinued bower bundles with our `1.0.0` release of dmn-js.

Checkout our [pre-packaged example](../pre-packaged) for alternative.
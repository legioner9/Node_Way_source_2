> Removed as of `dmn-js@1.0.0`.

Checkout [bundling example](../bundling) for alternative.
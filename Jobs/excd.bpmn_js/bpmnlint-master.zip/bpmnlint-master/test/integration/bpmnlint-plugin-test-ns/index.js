module.exports = {
  configs: {
    recommended: {
      rules: {
        'no-label-xxx': 'error'
      }
    }
  }
};
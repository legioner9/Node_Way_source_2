> Removed as of `bpmn-js@0.27.0`.

Checkout [bundling example](../bundling) for alternative.
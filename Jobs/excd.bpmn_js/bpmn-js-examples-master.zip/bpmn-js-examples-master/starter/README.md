# bpmn-js starter

Try out our toolkit by downloading the [viewer](https://cdn.staticaly.com/gh/bpmn-io/bpmn-js-examples/master/starter/viewer.html) or [modeler](https://cdn.staticaly.com/gh/bpmn-io/bpmn-js-examples/master/starter/modeler.html) example.


[![viewer example screenshot](./viewer.png)](https://cdn.staticaly.com/gh/bpmn-io/bpmn-js-examples/master/starter/viewer.html)

_Screenshot of the [viewer example](https://cdn.staticaly.com/gh/bpmn-io/bpmn-js-examples/master/starter/viewer.html)._
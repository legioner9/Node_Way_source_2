import MagicPropertiesProvider from './MagicPropertiesProvider';

export default {
  __init__: [ 'magicPropertiesProvider' ],
  magicPropertiesProvider: [ 'type', MagicPropertiesProvider ]
};
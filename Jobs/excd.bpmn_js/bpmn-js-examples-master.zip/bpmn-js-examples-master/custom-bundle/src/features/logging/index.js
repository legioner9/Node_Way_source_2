import InteractionLogger from './InteractionLogger';

export default {
  __init__: [ 'interactionLogger' ],
  interactionLogger: [ 'type', InteractionLogger ]
};
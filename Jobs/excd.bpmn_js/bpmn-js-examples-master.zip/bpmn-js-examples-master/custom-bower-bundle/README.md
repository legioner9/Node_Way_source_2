> Removed as of `bpmn-js@0.27.0`.

Checkout [custom bundle example](../custom-bundle) for alternative.
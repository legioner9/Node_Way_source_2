import Textarea from './Textarea';

export default {
  __init__: [ 'textarea' ],
  textarea: [ 'type', Textarea ]
};
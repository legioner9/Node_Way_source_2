import DecisionProperties from './DecisionProperties';

export default {
  __init__: [ 'decisionProperties' ],
  decisionProperties: [ 'type', DecisionProperties ]
};
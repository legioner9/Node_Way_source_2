import ExpressionLanguages from './ExpressionLanguages';

export default {
  __init__: [ 'expressionLanguages' ],
  expressionLanguages: [ 'type', ExpressionLanguages ]
};
import DiGenerator from './DiGenerator';

export default {
  __init__: [ 'diGenerator' ],
  diGenerator: [ 'type', DiGenerator ]
};
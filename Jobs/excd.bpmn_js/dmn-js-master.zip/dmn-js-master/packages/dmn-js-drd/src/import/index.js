import DrdImporter from './DrdImporter';

export default {
  drdImporter: [ 'type', DrdImporter ]
};
import DrawModule from '../draw';
import ImportModule from '../import';

export default {
  __depends__: [
    DrawModule,
    ImportModule
  ]
};

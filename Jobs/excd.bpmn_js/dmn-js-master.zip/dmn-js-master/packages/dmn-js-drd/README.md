# dmn-js-drd

A decision requirements diagram viewer and editor for [dmn-js](https://github.com/bpmn-io/dmn-js).


## License

Use under the terms of the [bpmn.io license](http://bpmn.io/license).
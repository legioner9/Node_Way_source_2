import AnnotationsProvider from './AnnotationsProvider';

export default {
  __init__: [ 'annotationsProvider' ],
  annotationsProvider: [ 'type', AnnotationsProvider ]
};
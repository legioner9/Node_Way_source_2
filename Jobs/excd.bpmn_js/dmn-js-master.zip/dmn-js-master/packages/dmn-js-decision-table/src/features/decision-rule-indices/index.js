import DecisionRuleIndices from './DecisionRuleIndices';

export default {
  __init__: [ 'decisionRuleIndices' ],
  decisionRuleIndices: [ 'type', DecisionRuleIndices ]
};
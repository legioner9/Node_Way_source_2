import HitPolicyProvider from './HitPolicyProvider';

export default {
  __init__: [ 'hitPolicyProvider' ],
  hitPolicyProvider: [ 'type', HitPolicyProvider ]
};
import DecisionTableProperties from './DecisionTableProperties';

export default {
  __init__: [ 'decisionTableProperties' ],
  decisionTableProperties: [ 'type', DecisionTableProperties ]
};
import PoweredBy from './PoweredBy';

export default {
  __init__: [ 'poweredBy' ],
  poweredBy: [ 'type', PoweredBy ]
};
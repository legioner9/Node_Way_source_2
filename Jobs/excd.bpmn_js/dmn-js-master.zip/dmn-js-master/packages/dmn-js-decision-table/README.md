# dmn-js-decision-table

A decision table viewer and editor for [dmn-js](https://github.com/bpmn-io/dmn-js).


## License

Use under the terms of the [bpmn.io license](http://bpmn.io/license).
module.exports = {
  __init__: [ 'customRules' ],
  customRules: [ 'type', require('./CustomRules') ]
};

# Безопасность информационных систем

- [SQL Injection](https://youtu.be/Pdfo1G-gI6s)
  - https://github.com/HowProgrammingWorks/SQLInjection
- [Path Traversal Attack](https://youtu.be/Pdfo1G-gI6s)
  - https://github.com/HowProgrammingWorks/PathTraversal
- Cross-Site Request Forgery (CSRF)
  - https://github.com/HowProgrammingWorks/CSRF
- Cross-site Scripting (XSS)
  - https://github.com/HowProgrammingWorks/XSS
- Denial of Service (DoS)
  - https://github.com/HowProgrammingWorks/DoS

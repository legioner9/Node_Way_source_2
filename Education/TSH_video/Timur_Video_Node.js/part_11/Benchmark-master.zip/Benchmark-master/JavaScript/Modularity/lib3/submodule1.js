'use strict';

module.exports = (api) => {

  api.moduleName.first = (value) => {
    return value;
  };

  api.moduleName.second = (value) => {
    return value;
  };

};

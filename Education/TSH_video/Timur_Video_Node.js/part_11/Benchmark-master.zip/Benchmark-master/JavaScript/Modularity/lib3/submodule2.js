'use strict';

module.exports = (api) => {

  api.moduleName.third = (value) => {
    return value;
  };

  api.moduleName.fourth = (value) => {
    return value;
  };

};

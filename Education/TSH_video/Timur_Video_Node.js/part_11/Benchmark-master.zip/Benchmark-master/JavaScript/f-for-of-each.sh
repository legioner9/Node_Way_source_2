#!/bin/sh
node --allow-natives-syntax --nouse-idle-notification f-for-of-each

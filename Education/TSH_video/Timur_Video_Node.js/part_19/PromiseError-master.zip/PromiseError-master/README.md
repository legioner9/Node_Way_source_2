## Catch, unhandledRejection, rejectionHandled and multipleResolves

[![Необработанные ошибки в промисах на Node.js](https://img.youtube.com/vi/1Ml5NE2fsZ8/0.jpg)](https://www.youtube.com/watch?v=1Ml5NE2fsZ8)

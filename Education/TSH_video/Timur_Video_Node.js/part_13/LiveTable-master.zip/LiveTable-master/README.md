# LiveTable
[![WebSocket сервер на Node.js (электронные таблицы и чат)](https://img.youtube.com/vi/Sf7ln3n16ws/0.jpg)](https://www.youtube.com/watch?v=Sf7ln3n16ws)

Multiuser spreadsheet example

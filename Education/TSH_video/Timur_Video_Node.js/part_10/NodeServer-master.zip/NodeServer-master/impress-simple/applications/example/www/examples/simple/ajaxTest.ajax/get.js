(client, callback) => {
  callback({ parameterName: client.query.parameterName });
}
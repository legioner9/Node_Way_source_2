(client, callback) => {
  callback(api.news.listTitles());
}
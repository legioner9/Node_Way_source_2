[
  // Hosts (and IPs) array to be handled by application
  // Wildcard '*' is allowed for masking random or empty substring

  '*',                // all
  // '127.0.0.1',      // localhost or IP
  // 'domain.com',    // domain name
  // '*.domain.com',  // masked domain name
]
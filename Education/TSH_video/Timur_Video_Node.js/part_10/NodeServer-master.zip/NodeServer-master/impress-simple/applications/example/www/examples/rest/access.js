{
  guests:  true,
  logged:  true,
  http:    true,
  https:   true,
  intro:   true,
  virtual: true,
  groups:  []
}
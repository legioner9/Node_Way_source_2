(client, callback) => {
  callback({ path: client.path });
}
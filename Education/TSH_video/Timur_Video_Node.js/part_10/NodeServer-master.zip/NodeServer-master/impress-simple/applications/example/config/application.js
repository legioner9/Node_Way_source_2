{
  // Application configuration

  slowTime:    '1s',
  // preload:     true, // preload application to memory at startup (default: false)
  // allowOrigin: '*'   // set HTTP header Access-Control-Allow-Origin (default: not set)
}
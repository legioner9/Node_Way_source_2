{
  guests: true,
  logged: true,
  http:   true,
  https:  true,
  groups: []
}
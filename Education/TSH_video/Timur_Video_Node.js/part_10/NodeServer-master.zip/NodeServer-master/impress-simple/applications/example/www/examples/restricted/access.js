{
  realm: 'Restricted area',
  auth: 'user:password'
}
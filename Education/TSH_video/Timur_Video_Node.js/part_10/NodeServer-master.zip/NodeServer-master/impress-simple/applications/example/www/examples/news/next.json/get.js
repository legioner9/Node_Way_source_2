(client, callback) => {
  callback(api.news.getNext());
}
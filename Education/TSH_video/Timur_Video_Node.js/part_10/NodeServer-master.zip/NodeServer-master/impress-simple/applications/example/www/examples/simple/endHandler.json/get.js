(client, callback) => {
  console.log('Verb handler: get.js');
  callback({ handler: 'get' });
}
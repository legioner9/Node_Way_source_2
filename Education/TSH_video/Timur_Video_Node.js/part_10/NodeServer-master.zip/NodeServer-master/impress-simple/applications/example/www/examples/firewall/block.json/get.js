(client, callback) => {
  client.block();
  callback();
}
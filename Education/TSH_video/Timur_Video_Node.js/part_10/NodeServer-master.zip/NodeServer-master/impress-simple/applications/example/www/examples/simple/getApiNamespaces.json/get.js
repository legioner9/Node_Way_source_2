(client, callback) => {
  callback(Object.keys(api));
}
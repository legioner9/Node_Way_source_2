{
  // Application specific configuration
  // You can place js file in this directory with your own structure and it will be loaded as an application config section

  parameter: 'value',

  subSection: {
    parameter: 'value'
  }

}
(client, callback) => {
  client.attachment('fileName.csv');
  callback([
    ['name1', 11, 21.1],
    ['name2', 12, 22.2],
    ['name3', 13, 23.3],
    ['name4', 14, 24.4],
    ['name5', 15, 25.5],
  ]);
}
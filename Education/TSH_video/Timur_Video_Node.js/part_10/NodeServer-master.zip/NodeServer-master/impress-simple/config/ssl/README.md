Place here:
  * Certificates (.cer files) from your to root authority
  * Private keys (.key files)
# Prototype
[![Массивы, объекты, классы, прототипы](https://img.youtube.com/vi/VBMGnAPfmsY/0.jpg)](https://www.youtube.com/watch?v=VBMGnAPfmsY)

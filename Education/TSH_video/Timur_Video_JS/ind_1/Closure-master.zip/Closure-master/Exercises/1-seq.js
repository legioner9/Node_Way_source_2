'use strict';

const seq = f => g => x => 0;

module.exports = { seq };

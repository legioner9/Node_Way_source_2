'use strict';

const contract = (fn, ...types) => null;

module.exports = { contract };

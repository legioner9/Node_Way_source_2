'use strict';

console.log('Hello'.padEnd(10) + '!');
console.log('Hello'.padStart(10) + '!');

'use strict';

const name = 'Marcus Aurelius';

console.log();
console.log(`name = ${name}`);

console.log();
console.log(`name.indexOf('Aur') = ${name.indexOf('Aur')}`);
console.log(`name.lastIndexOf('u') = ${name.lastIndexOf('u')}`);
console.log(`name.includes('Ma') = ${name.includes('Ma')}`);
console.log(`name.startsWith('re') = ${name.startsWith('re')}`);
console.log(`name.endsWith('lius') = ${name.endsWith('lius')}`);

## Композиция функций

[![Композиция функций (pipe, compose) в JavaScript](https://img.youtube.com/vi/xS9FicVrOTI/0.jpg)](https://www.youtube.com/watch?v=xS9FicVrOTI)

'use strict';

const pipe = (...fns) => x => null;

module.exports = { pipe };

'use strict';

const power = null;
const square = null;
const cube = null;

module.exports = { power, square, cube };

'use strict';

require('./names');
require('./submodules');
